import asciiTable

class table_T_S_I_J_(asciiTable.asciiTable):
	pass

