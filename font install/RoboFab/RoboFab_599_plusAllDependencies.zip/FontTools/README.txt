See the file "documentation.html" in the "Doc" subdirectory for TTX
usage instructions and information about the TTX file format.

See the file "install.txt" in the "Doc" subdirectory for instructions
how to build and install TTX/FontTools from the sources.

Quick start: run python setup.py install from the command line.

See the file "LICENSE.txt" for licensing info.

Have fun!

Just van Rossum <just@letterror.com>
