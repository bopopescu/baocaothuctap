from AppKit import *
from vanillaButton import ImageButton


class GradientButton(ImageButton):

    nsBezelStyle = NSSmallSquareBezelStyle

