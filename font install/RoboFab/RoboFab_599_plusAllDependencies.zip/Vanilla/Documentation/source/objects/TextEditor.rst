.. highlight:: python

==========
TextEditor
==========

.. module:: vanilla
.. autoclass:: TextEditor
   :inherited-members:
   :members: