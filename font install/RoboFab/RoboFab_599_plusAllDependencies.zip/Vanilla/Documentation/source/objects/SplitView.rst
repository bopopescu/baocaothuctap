.. highlight:: python

=========
SplitView
=========

.. module:: vanilla
.. autoclass:: SplitView
   :inherited-members:
   :members: