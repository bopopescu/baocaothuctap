.. highlight:: python

========
EditText
========

.. module:: vanilla
.. autoclass:: EditText
   :inherited-members:
   :members: