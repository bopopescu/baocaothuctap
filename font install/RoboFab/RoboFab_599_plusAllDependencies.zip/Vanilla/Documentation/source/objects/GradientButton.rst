.. highlight:: python

==============
GradientButton
==============

.. module:: vanilla
.. autoclass:: GradientButton
   :inherited-members:
   :members: