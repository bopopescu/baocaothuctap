.. highlight:: python

======
Drawer
======

.. module:: vanilla
.. autoclass:: Drawer
   :inherited-members:
   :members: