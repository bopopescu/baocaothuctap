.. highlight:: python

=====
Group
=====

.. module:: vanilla
.. autoclass:: Group
   :inherited-members:
   :members: