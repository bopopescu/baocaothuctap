.. highlight:: python

===============
SegmentedButton
===============

.. module:: vanilla
.. autoclass:: SegmentedButton
   :inherited-members:
   :members: