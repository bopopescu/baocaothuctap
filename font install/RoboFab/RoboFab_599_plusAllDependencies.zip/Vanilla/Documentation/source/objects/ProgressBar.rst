.. highlight:: python

===========
ProgressBar
===========

.. module:: vanilla
.. autoclass:: ProgressBar
   :inherited-members:
   :members: