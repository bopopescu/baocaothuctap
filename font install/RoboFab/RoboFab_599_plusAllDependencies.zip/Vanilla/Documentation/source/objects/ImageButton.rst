.. highlight:: python

===========
ImageButton
===========

.. module:: vanilla
.. autoclass:: ImageButton
   :inherited-members:
   :members: