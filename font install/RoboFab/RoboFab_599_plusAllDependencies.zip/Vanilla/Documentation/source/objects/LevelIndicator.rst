.. highlight:: python

==============
LevelIndicator
==============

.. module:: vanilla
.. autoclass:: LevelIndicator
   :inherited-members:
   :members: