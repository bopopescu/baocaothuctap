.. highlight:: python

=========
SearchBox
=========

.. module:: vanilla
.. autoclass:: SearchBox
   :inherited-members:
   :members: