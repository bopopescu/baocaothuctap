.. highlight:: python

======
Button
======

.. module:: vanilla
.. autoclass:: Button
   :inherited-members:
   :members: