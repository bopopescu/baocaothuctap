.. highlight:: python

==========
HelpButton
==========

.. module:: vanilla
.. autoclass:: HelpButton
   :inherited-members:
   :members: