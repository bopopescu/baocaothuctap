.. highlight:: python

============
SquareButton
============

.. module:: vanilla
.. autoclass:: SquareButton
   :inherited-members:
   :members: