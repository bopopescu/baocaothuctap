.. highlight:: python

===
Box
===

.. module:: vanilla
.. autoclass:: Box
   :inherited-members:
   :members: