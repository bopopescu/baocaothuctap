.. highlight:: python

===========
PopUpButton
===========

.. module:: vanilla
.. autoclass:: PopUpButton
   :inherited-members:
   :members: