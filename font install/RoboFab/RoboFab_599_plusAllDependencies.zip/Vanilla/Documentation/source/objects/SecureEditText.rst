.. highlight:: python

==============
SecureEditText
==============

.. module:: vanilla
.. autoclass:: SecureEditText
   :inherited-members:
   :members: