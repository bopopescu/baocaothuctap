.. highlight:: python

========
CheckBox
========

.. module:: vanilla
.. autoclass:: CheckBox
   :inherited-members:
   :members: