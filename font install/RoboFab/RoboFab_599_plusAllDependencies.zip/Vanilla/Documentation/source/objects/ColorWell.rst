.. highlight:: python

=========
ColorWell
=========

.. module:: vanilla
.. autoclass:: ColorWell
   :inherited-members:
   :members: