.. highlight:: python

==========
DatePicker
==========

.. module:: vanilla
.. autoclass:: DatePicker
   :inherited-members:
   :members: