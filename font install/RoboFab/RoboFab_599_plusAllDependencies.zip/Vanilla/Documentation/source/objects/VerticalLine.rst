.. highlight:: python

============
VerticalLine
============

.. module:: vanilla
.. autoclass:: VerticalLine
   :inherited-members:
   :members: