.. highlight:: python

======
Slider
======

.. module:: vanilla
.. autoclass:: Slider
   :inherited-members:
   :members: