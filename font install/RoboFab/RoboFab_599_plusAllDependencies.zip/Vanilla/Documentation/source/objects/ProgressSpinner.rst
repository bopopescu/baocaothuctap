.. highlight:: python

===============
ProgressSpinner
===============

.. module:: vanilla
.. autoclass:: ProgressSpinner
   :inherited-members:
   :members: