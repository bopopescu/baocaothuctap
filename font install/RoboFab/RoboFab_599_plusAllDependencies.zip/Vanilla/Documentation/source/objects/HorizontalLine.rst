.. highlight:: python

==============
HorizontalLine
==============

.. module:: vanilla
.. autoclass:: HorizontalLine
   :inherited-members:
   :members: