.. highlight:: python

=======
TextBox
=======

.. module:: vanilla
.. autoclass:: TextBox
   :inherited-members:
   :members: