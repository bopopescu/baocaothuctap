# environment: FontLab
# version: All
# platform: Mac (untested in Windows)
# dialogKit object: PopUpButton
# description: The object looks like a combo box, but it behaves like a pop-up button.
# cause: This is a limitation of FontLab's Dialog class.