# environment: FontLab
# version: All
# platform: Mac (untested in Windows)
# dialogKit object: List
# description: Multiple selection in the list is not allowed.
# cause: This a limitation of FontLab's Dialog class.