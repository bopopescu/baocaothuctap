.. _ref-cloudtrail:

==========
CloudTrail
==========

boto.cloudtrail
---------------

.. automodule:: boto.cloudtrail
   :members:
   :undoc-members:

boto.cloudtrail.layer1
----------------------

.. automodule:: boto.cloudtrail.layer1
   :members:
   :undoc-members:

boto.cloudtrail.exceptions
--------------------------

.. automodule:: boto.cloudtrail.exceptions
   :members:
   :undoc-members:
